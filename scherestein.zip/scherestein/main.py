

from random import randint
from kivy.lang import Builder
from kivy.uix.screenmanager import ScreenManager, Screen
import sys
from kivy.uix.image import Image
from kivy.animation import Animation
from kivy.clock import Clock
from kivy.uix.behaviors import ButtonBehavior
from kivy.app import App

my_global = ""
computer_sagt = ""
ausgang = ""
wins = 0
losses = 0
ties = 0
class ImageButton(ButtonBehavior,Image):
    pass
class Rotation(Image):
    pass



class Startwindow(Screen):

    def wait(self):
        Clock.schedule_once(self.haupt, 3)

    def haupt(self,*args):
        sm.current = "main"

class MainWindow(Screen):
    def exi(self):
        sys.exit()
    def choose(self):
        global computer_sagt
        computer_sagt = randint(1,3)
    def win(self):
        global wins
        wins +=1
    def lost(self):
        global losses
        losses +=1
    def tie(self):
        global ties
        ties += 1
    def antwort(self):
        a = u"Stein schlägt Schere kaputt"
        b = "Schere zerschneidet Papier"
        c = "Papier wickelt den Stein ein"
        d = ", du gewinnst"
        e = ", du verlierst"
        f = "Wir haben beide das Selbe, nichts passiert."
        if (my_global == "Schere" and computer_sagt == 1) or (my_global == "Stein" and computer_sagt == 2) or (my_global == "Papier" and computer_sagt == 3):
            self.tie()
            return f
        elif my_global == "Schere" and computer_sagt == 2:
            self.lost()
            return a+e
        elif my_global == "Schere" and computer_sagt == 3:
            self.win()
            return b+d
        elif my_global == "Stein" and computer_sagt == 1:
            self.win()
            return a+d
        elif my_global == "Stein" and computer_sagt == 3:
            self.lost()
            return c+e
        elif my_global == "Papier" and computer_sagt == 1:
            self.lost()
            return b+e
        elif my_global == "Papier" and computer_sagt == 2:
            self.win()
            return c+d
        else:
            return "wtf"
    def game(self):
        global computer_sagt
        computer_sagt = randint(1,3)
        global ausgang
        ausgang = self.antwort()

    def setglobal(self,newglobal):
        global my_global
        my_global = newglobal
    def changelabel(self,new):
        self.ids.est.text = new
    def changelabelback(self):
        self.ids.est.text = u'Du w\u00E4hlst'

class SecondWindow(Screen):
    def getErgeb(self):
        global wins, losses, ties
        return "Gewonnen: "+str(wins)+", Verloren: "+str(losses)+", Gleichstand: "+str(ties)
    def getTitle(self):
        return ausgang
    def update(self):
        self.ids.nun.text = self.getTitle()
        self.ids.ergeb.text = self.getErgeb()
        if losses > 0:
            self.ids.boxi.size_hint_x = wins/(wins+losses)*0.6
        elif wins > 0:
            self.ids.boxi.size_hint_x = 0.6



class Betweenwindow(Screen):
    def between(self):
        Clock.schedule_once(self.Callback_Clock, 1)
        Clock.schedule_once(self.Clock_zwei, 2.5)
        Clock.schedule_once(self.wechsel,4)

    def wechsel(self,*args):
        sm.current = "second"


    def Clock_zwei(self,dt):
        if computer_sagt == 1:
            self.ids.zwischen.text = "Schere"
            self.ids.picture.source = "schere.png"
        elif computer_sagt == 2:
            self.ids.zwischen.text = "Stein"
            self.ids.picture.source = "stein.png"
        else:
            self.ids.zwischen.text = "Papier"
            self.ids.picture.source = "papier.png"
    def Callback_Clock(self, dt):
        global my_global
        self.ids.zwischen.text = my_global+" gegen..."
        if my_global == "Stein":
            self.ids.picture.source = "stein.png"
        elif my_global == "Schere":
            self.ids.picture.source = "schere.png"
        else:
            self.ids.picture.source = "papier.png"

    def changelabelback(self):
        self.ids.zwischen.text = u'Es k\u00E4mpft:...'
        self.ids.picture.source = "start.png"

class WindowManager(ScreenManager):
    pass
kv = Builder.load_file("my.kv")

sm = WindowManager()
screens = [MainWindow(name="main"), Betweenwindow(name="between"),SecondWindow(name="second"),Startwindow(name="start")]
for screen in screens:
    sm.add_widget(screen)
sm.current = "start"

class MyMainApp(App):
    def animate_widget(self,widget,*args):
        anim=Animation(angle=-900,duration=3)
        anim.start(widget)
    def build(self):
        return sm

if __name__ == "__main__":
    MyMainApp().run()


